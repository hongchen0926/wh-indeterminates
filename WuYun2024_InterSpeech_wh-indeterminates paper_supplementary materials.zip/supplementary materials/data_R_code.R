# Use the tidyverse package
library(tidyverse)
library(lme4)
library(report) 
library(stringr)
library(dplyr)
library(ggsignif)
library(ggpubr)
library(ggplot2)
library(gridExtra)
library(cowplot)


# Read the data
df <- read_csv("data.csv") 


##log pitch and pitch excursion
# pitch excursion calculation
# raw_pitch_excursion = max_pitch - min_pitch
df <-
  df %>%
  mutate(Max_pitch_Log = log(as.numeric(Max_pitch)),
         Min_pitch_Log = log(as.numeric(Min_pitch)),
         Pitch_Ex = as.numeric(Max_pitch) - as.numeric(Min_pitch),
         Pitch_Ex_Log = log(Pitch_Ex)
  )


###By-speaker normalization using z-score:
Max_pitch_Z <- c()
Min_pitch_Z <- c()
Pitch_Ex_Z <- c()
Max_pitch_Log_Z <- c()
Min_pitch_Log_Z <- c()
Pitch_Ex_Log_Z <- c()

participant_list= unique(df$Participant)
#for (i in participant_list) {print(noquote(i))}


for (i in participant_list) {
  pi <- # data frame for ith participant
    df %>%
    filter(Participant == noquote(i)) %>%
    select(Max_pitch, Min_pitch, Max_pitch_Log, Min_pitch_Log, 
           Pitch_Ex, Pitch_Ex_Log)
  # Raw pitch
  pi_vector <- as.numeric(c(pi$Max_pitch, pi$Min_pitch, pi$Pitch_Ex))
  pi_mean <- mean(pi_vector)
  pi_sd <- sd(pi_vector)
  pi_Max_pitch_Z <- (as.numeric(pi$Max_pitch) - as.numeric(pi_mean))/pi_sd
  pi_Min_pitch_Z <- (as.numeric(pi$Min_pitch) - as.numeric(pi_mean))/pi_sd
  pi_Pitch_Ex_Z <- (as.numeric(pi$Pitch_Ex) - as.numeric(pi_mean))/pi_sd
  Max_pitch_Z <- append(Max_pitch_Z, pi_Max_pitch_Z)
  Min_pitch_Z <- append(Min_pitch_Z, pi_Min_pitch_Z)
  Pitch_Ex_Z <- append(Pitch_Ex_Z, pi_Pitch_Ex_Z)
  # Log pitch
  pi_vector <- c(pi$Max_pitch_Log, pi$Min_pitch_Log, pi$Pitch_Ex_Log)
  pi_mean <- mean(pi_vector)
  pi_sd <- sd(pi_vector)
  pi_Max_pitch_Log_Z <- (as.numeric(pi$Max_pitch_Log) - as.numeric(pi_mean))/pi_sd
  pi_Min_pitch_Log_Z <- (as.numeric(pi$Min_pitch_Log) - as.numeric(pi_mean))/pi_sd
  pi_Pitch_Ex_Log_Z <- (as.numeric(pi$Pitch_Ex_Log) - as.numeric(pi_mean))/pi_sd
  Max_pitch_Log_Z <- append(Max_pitch_Log_Z, pi_Max_pitch_Log_Z)
  Min_pitch_Log_Z <- append(Min_pitch_Log_Z, pi_Min_pitch_Log_Z)
  Pitch_Ex_Log_Z <- append(Pitch_Ex_Log_Z, pi_Pitch_Ex_Log_Z)
}
df$Max_pitch_Z <- Max_pitch_Z
df$Min_pitch_Z <- Min_pitch_Z
df$Pitch_Ex_Z <- Pitch_Ex_Z
df$Max_pitch_Log_Z <- Max_pitch_Log_Z
df$Min_pitch_Log_Z <- Min_pitch_Log_Z
df$Pitch_Ex_Log_Z <- Pitch_Ex_Log_Z
# Remove temporary variables
rm(i, pi, pi_vector, pi_mean, pi_sd,
   pi_Max_pitch_Z, pi_Min_pitch_Z, pi_Pitch_Ex_Z,
   Max_pitch_Z, Min_pitch_Z, Pitch_Ex_Z,
   Max_pitch_Log_Z, Min_pitch_Log_Z, Pitch_Ex_Log_Z)


### check how many participants whose corresponding column (Meaning) in the data
#####frame (df) does not contain the substring 'interro'/ 'indef'
excluded_participants <- list()
for (i in participant_list) {
  meaning_values <- df$Meaning[df$Participant == i]
  
  if (!any(grepl('interro', meaning_values, ignore.case = TRUE)) ||
      !any(grepl('indef', meaning_values, ignore.case = TRUE))) {
    excluded_participants <- c(excluded_participants, i)
    print(noquote(i))
  }
}

# Filter out data for excluded participants
excluded_participants <- unique(excluded_participants)
filtered_df <- df[!(df$Participant %in% excluded_participants), ] 
# If you also want to get a list of participants meeting the criteria:
selected_participants <- unique(filtered_df$Participant)
length(selected_participants)

# Filter out data for z-score greater or smaller than 3
filtered_df <- df[!(df$Max_pitch_Z > 3 | df$Max_pitch_Z < -3) & 
                    !(df$Pitch_Ex_Z > 3 | df$Pitch_Ex_Z < -3), ]

#5331-> remove nas --> 5115 --> remove outlier --> 5006



#### statistical 
wh_region=filter(filtered_df, Meaning == "indef"|Meaning == "interro", Label == "wh") 

morphology_levels <- c("none", "dehua", "ruguo", "ruguo_dehua")
wh_region$Morphology <- factor(wh_region$Morphology, levels = morphology_levels)

fm.full.Max_pitch_Z <- lmer(Max_pitch_Z~Meaning+Morphology+(1|Participant), data=wh_region, REML=FALSE)
report(fm.full.Max_pitch_Z)
report_table(fm.full.Max_pitch_Z)
fm.full.Max_pitch_Z.1 <- lmer(Max_pitch_Z~Morphology*Meaning+(1|Participant), data=wh_region, REML=FALSE)
anova(fm.full.Max_pitch_Z, fm.full.Max_pitch_Z.1)
##meaning and position of wh is not inter-dependent factor
summary(fm.full.Max_pitch_Z,correlation=FALSE)


fm.full.Pitch_Ex_Z <- lmer(Pitch_Ex_Z~Meaning+Morphology+(1|Participant), data=wh_region, REML=FALSE)
report(fm.full.Pitch_Ex_Z)
report_table(fm.full.Pitch_Ex_Z)
fm.full.Pitch_Ex_Z.1 <- lmer(Pitch_Ex_Z~Morphology*Meaning+(1|Participant), data=wh_region, REML=FALSE)
anova(fm.full.Pitch_Ex_Z, fm.full.Pitch_Ex_Z.1)
##meaning and position of wh is not inter-dependent factor
summary(fm.full.Pitch_Ex_Z,correlation=FALSE)

fm.full.Duration_in_ms <- lmer(Duration_in_ms~Meaning+Morphology+(1|Participant), data=wh_region, REML=FALSE)
report(fm.full.Duration_in_ms)
report_table(fm.full.Duration_in_ms)
fm.full.Duration_in_ms.1 <- lmer(Duration_in_ms~Morphology*Meaning+(1|Participant), data=wh_region, REML=FALSE)
anova(fm.full.Duration_in_ms, fm.full.Duration_in_ms.1)
##meaning and position of wh is not inter-dependent factor
summary(fm.full.Duration_in_ms,correlation=FALSE)

fm.full.Max_dB <- lmer(Max_dB~Meaning+Morphology+(1|Participant), data=wh_region, REML=FALSE)
report(fm.full.Max_dB)
report_table(fm.full.Max_dB)
fm.full.Max_dB.1 <- lmer(Max_dB~Morphology*Meaning+(1|Participant), data=wh_region, REML=FALSE)
anova(fm.full.Max_dB, fm.full.Max_dB.1)
##meaning and position of wh is not inter-dependent factor
summary(fm.full.Max_dB,correlation=FALSE)


##ruguo initial versus non-ruguo initial;  
fm.full.Max_pitch_Z <- lmer(Max_pitch_Z~Meaning+RuguoInitial+(1|Participant), data=wh_region, REML=FALSE)
report(fm.full.Max_pitch_Z)
fm.full.Pitch_Ex_Z <- lmer(Pitch_Ex_Z~Meaning+RuguoInitial+(1|Participant), data=wh_region, REML=FALSE)
report(fm.full.Pitch_Ex_Z)
fm.full.Duration_in_ms <- lmer(Duration_in_ms~Meaning+RuguoInitial+(1|Participant), data=wh_region, REML=FALSE)
report(fm.full.Duration_in_ms)
fm.full.Max_dB <- lmer(Max_dB~Meaning+RuguoInitial+(1|Participant), data=wh_region, REML=FALSE)
report(fm.full.Max_dB)

### ruguo versus ruguo dehua; 
morphology_levels <- c("ruguo", "ruguo_dehua", "none", "dehua")
wh_region$Morphology <- factor(wh_region$Morphology, levels = morphology_levels)
wh_region_ruguo=filter(wh_region, Meaning == "indef"|Meaning == "interro", RuguoInitial == "ruguo") 
fm.full.Max_pitch_Z <- lmer(Max_pitch_Z~Meaning+Morphology+(1|Participant), data=wh_region_ruguo, REML=FALSE)
report(fm.full.Max_pitch_Z)
fm.full.Pitch_Ex_Z <- lmer(Pitch_Ex_Z~Meaning+Morphology+(1|Participant), data=wh_region_ruguo, REML=FALSE)
report(fm.full.Pitch_Ex_Z)
fm.full.Duration_in_ms <- lmer(Duration_in_ms~Meaning+Morphology+(1|Participant), data=wh_region_ruguo, REML=FALSE)
report(fm.full.Duration_in_ms)
fm.full.Max_dB <- lmer(Max_dB~Meaning+Morphology+(1|Participant), data=wh_region_ruguo, REML=FALSE)
report(fm.full.Max_dB)


##descriptive data: Effect of morphology on wh_prosody:
morphology_levels <- c("none", "dehua", "ruguo", "ruguo_dehua")
wh_region$Morphology <- factor(wh_region$Morphology, levels = morphology_levels)

# Plot 1
plot1 <- ggplot(aes(x = Morphology, y = Max_pitch_Z, fill = Meaning), data = wh_region) + 
  geom_boxplot() +
  theme_minimal() +
  theme(legend.position = "none")        # Remove legend

# Significance stars and labels for plot 1
plot1 <- plot1 +
  annotate("text", x = 1.45, y = max(wh_region$Max_pitch_Z)-0.15, label = "NS", size = 3, color = "red") +  
  geom_segment(aes(x = 0.85, xend = 2.10, y = max(Max_pitch_Z) - 0.3, yend = max(Max_pitch_Z) - 0.3), 
               color = "red", size = 0.01)+
  annotate("text", x = 3.45, y = max(wh_region$Max_pitch_Z)-0.15, label = "NS", size = 3, color = "red") +  
  geom_segment(aes(x = 2.85, xend = 4.10, y = max(Max_pitch_Z) - 0.3, yend = max(Max_pitch_Z) - 0.3), 
               color = "red", size = 0.01)+
  annotate("text", x = 2.5, y = max(wh_region$Max_pitch_Z)+0.1, label = "***", size = 6, color = "red") +  
  geom_segment(aes(x = 1.45, xend = 3.45, y = max(Max_pitch_Z) + 0.05, yend = max(Max_pitch_Z) + 0.05), 
               color = "red", size = 0.01)

# Plot 2
plot2 <- ggplot(aes(x = Morphology, y = Pitch_Ex_Z, fill = Meaning), data = wh_region) + 
  geom_boxplot() +
  theme_minimal() +
  theme(legend.position = "none")        # Remove legend
# Significance stars and labels for plot 2
plot2 <- plot2 +
  annotate("text", x = 1.45, y = max(wh_region$Pitch_Ex_Z)-0.5, label = "NS", size = 3, color = "red") +  
  geom_segment(aes(x = 0.85, xend = 2.10, y = max(Pitch_Ex_Z) - 0.7, yend = max(Pitch_Ex_Z) - 0.7), 
               color = "red", size = 0.01)+
  annotate("text", x = 3.45, y = max(wh_region$Pitch_Ex_Z)-0.5, label = "NS", size = 3, color = "red") +  
  geom_segment(aes(x = 2.85, xend = 4.10, y = max(Pitch_Ex_Z) - 0.7, yend = max(Pitch_Ex_Z) - 0.7), 
               color = "red", size = 0.01)+
  annotate("text", x = 2.5, y = max(wh_region$Pitch_Ex_Z)-0.1, label = "***", size = 6, color = "red") +  
  geom_segment(aes(x = 1.45, xend = 3.45, y = max(Pitch_Ex_Z) - 0.2, yend = max(Pitch_Ex_Z) - 0.2), 
               color = "red", size = 0.01)

plot3 <- ggplot(aes(x = Morphology, y = Duration_in_ms, fill = Meaning), data = wh_region) + 
  geom_boxplot() +
  theme_minimal() +
  theme(legend.position = "none")       # Remove legend
# Significance stars and labels for plot 3
plot3 <- plot3 +
  annotate("text", x = 1.45, y = max(wh_region$Duration_in_ms)-155, label = "NS", size = 3, color = "red") +  
  geom_segment(aes(x = 0.85, xend = 2.10, y = max(Duration_in_ms) - 205, yend = max(Duration_in_ms) - 205), 
               color = "red", size = 0.01)+
  annotate("text", x = 3.45, y = max(wh_region$Duration_in_ms)-155, label = "NS", size = 3, color = "red") +  
  geom_segment(aes(x = 2.85, xend = 4.10, y = max(Duration_in_ms) - 205, yend = max(Duration_in_ms) - 205), 
               color = "red", size = 0.01)+
  annotate("text", x = 2.5, y = max(wh_region$Duration_in_ms)-50, label = "NS", size = 3, color = "red") +  
  geom_segment(aes(x = 1.45, xend = 3.45, y = max(Duration_in_ms) -100, yend = max(Duration_in_ms) -100), 
               color = "red", size = 0.01)

# Plot 4
plot4 <- ggplot(aes(x = Morphology, y = Max_dB, fill = Meaning), data = wh_region) + 
  geom_boxplot() +
  theme_minimal()+  
  theme(legend.position = "right")        # Remove legend
# Significance stars and labels for plot 1
plot4 <- plot4 +
  annotate("text", x = 1.45, y = max(wh_region$Max_dB)-2, label = "NS", size = 3, color = "red") +  
  geom_segment(aes(x = 0.85, xend = 2.10, y = max(Max_dB) - 3, yend = max(Max_dB) - 3), 
               color = "red", size = 0.01)+
  annotate("text", x = 3.45, y = max(wh_region$Max_dB)-2, label = "NS", size = 3, color = "red") +  
  geom_segment(aes(x = 2.85, xend = 4.10, y = max(Max_dB) - 3, yend = max(Max_dB) - 3), 
               color = "red", size = 0.01)+
  annotate("text", x = 2.5, y = max(wh_region$Max_dB), label = "***", size = 6, color = "red") +  
  geom_segment(aes(x = 1.45, xend = 3.45, y = max(Max_dB) - 0.5, yend = max(Max_dB) - 0.5), 
               color = "red", size = 0.01)

print (plot1)
print (plot2)
print (plot3)
print (plot4)

# Combine all plots into one column
#combined_plots <- plot_grid(plot1, plot2, plot3, plot4, ncol = 1, align = "v")

# Add legend to the end of plot 4
#combined_plots_with_legend <- plot_grid(combined_plots,  nrow = 1, rel_widths = c(1, 0.1))

# Print the final combined plot with legend
#print(combined_plots)

## if printed out in two columns 
# Combine plot 1 and plot 2 in a row
#row1 <- plot_grid(plot1, plot2, ncol = 2, align = "h")

# Combine plot 3 and plot 4 in a row
#row2 <- plot_grid(plot3, plot4, ncol = 2, align = "h")

# Combine both rows into a single plot
# combined_plots <- plot_grid(row1, row2, nrow = 2, align = "v", axis = "l")

# Create a legend for the combined plots
# legend <- get_legend(plot4)

# Print the final combined plot with legend at the bottom
# final_combined_plots <- plot_grid(combined_plots, legend, nrow = 2, rel_heights = c(10, 1))

# Print the final combined plot
# print(final_combined_plots)
